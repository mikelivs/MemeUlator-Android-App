package edu.jermstadsbvcu.gradememeulator;

import android.content.Context;
import android.database.Cursor;
import android.support.test.InstrumentationRegistry;
import android.test.AndroidTestCase;
import android.test.RenamingDelegatingContext;

import org.junit.Before;
import org.junit.*;

import static org.junit.Assert.*;

/**
 * Created by Debbie on 4/3/2017.
 */

public class DataBaseHelperTest extends AndroidTestCase {
    private DataBaseHelper db;

    @Override
    public Context getContext() {
        return super.getContext();
    }

    @Before
    public void setup() throws Exception {
        RenamingDelegatingContext context = new RenamingDelegatingContext(getContext(), "test_");
        db = new DataBaseHelper(context); // This is just to clear the db

    }

   @Override
    public void tearDown() throws Exception {
        db.close();
        super.tearDown();
    }
    @Test
    public void testAdd()
    {
        String testClass = "TestClass";
        db.insertData(testClass);
        Cursor res = db.getInfo(db);
        res.moveToFirst();
        assertEquals(res, "TestClass" );

    }

}