package edu.jermstadsbvcu.gradememeulator;

// Tests the add button on New class page
//Bryce Kirby
//User story 14, scenario 2.
// As a user, I want my input class data to be saved so I can come back to my input for convenience.

//Scenario 1: When the user clicks "input new class", they should be able to type and add the name of their class.

//Scenario 2: When the user clicks add, their class information will be saved to the database

//Scenario 3: When the user advances to the main activity, they should be able to go back to the new class page.

import android.support.test.espresso.ViewInteraction;
import android.support.test.rule.ActivityTestRule;
import android.support.test.runner.AndroidJUnit4;
import android.test.suitebuilder.annotation.LargeTest;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;

import org.hamcrest.Description;
import org.hamcrest.Matcher;
import org.hamcrest.TypeSafeMatcher;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

import static android.support.test.espresso.Espresso.onView;
import static android.support.test.espresso.action.ViewActions.click;
import static android.support.test.espresso.matcher.ViewMatchers.isDisplayed;
import static android.support.test.espresso.matcher.ViewMatchers.withId;
import static android.support.test.espresso.matcher.ViewMatchers.withText;
import static org.hamcrest.Matchers.allOf;

@LargeTest
@RunWith(AndroidJUnit4.class)
public class NewMainActivityTest {

    @Rule
    public ActivityTestRule<NewMainActivity> mActivityTestRule = new ActivityTestRule<>(NewMainActivity.class);

    @Test
    public void newMainActivityTest() {
        ViewInteraction appCompatButton = onView(
                allOf(withId(R.id.btAddClass), withText("Add"), isDisplayed()));
        appCompatButton.perform(click());

        ViewInteraction linearLayout = onView(
                allOf(childAtPosition(
                        withId(R.id.list),
                        1),
                        isDisplayed()));
        linearLayout.perform(click());

    }

    private static Matcher<View> childAtPosition(
            final Matcher<View> parentMatcher, final int position) {

        return new TypeSafeMatcher<View>() {
            @Override
            public void describeTo(Description description) {
                description.appendText("Child at position " + position + " in parent ");
                parentMatcher.describeTo(description);
            }

            @Override
            public boolean matchesSafely(View view) {
                ViewParent parent = view.getParent();
                return parent instanceof ViewGroup && parentMatcher.matches(parent)
                        && view.equals(((ViewGroup) parent).getChildAt(position));
            }
        };
    }
}
