package edu.jermstadsbvcu.gradememeulator;

import org.junit.After;
import org.junit.Before;

import android.app.Activity;
import android.app.Instrumentation;
import android.support.test.rule.ActivityTestRule;

//import org.junit.After;
//import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;

import static android.support.test.InstrumentationRegistry.getInstrumentation;
import static android.support.test.espresso.Espresso.onView;
import static android.support.test.espresso.action.ViewActions.click;
import static android.support.test.espresso.matcher.ViewMatchers.withId;
import static junit.framework.Assert.assertNotNull;


import static org.junit.Assert.*;

/**
 * Created by Bryce Kirby on 3/25/17.
 */



public class userStory1Test {

    @Rule
    public ActivityTestRule<MainActivity> mainActivityTestRule = new ActivityTestRule<MainActivity>(MainActivity.class);

    private MainActivity testRule = null;

    Instrumentation.ActivityMonitor monitor = getInstrumentation().addMonitor(NewClassPage.class.getName(),null,false);

    @Before
    public void setUp() throws Exception {

        testRule = mainActivityTestRule.getActivity();


    }

    @Test
    public void testLaunchOfSecondActivityOnButtonClick(){

        assertNotNull(testRule.findViewById(R.id.ncButton));

        onView(withId(R.id.ncButton)).perform(click());

        Activity NewClassPage = getInstrumentation().waitForMonitorWithTimeout(monitor,5000);

        assertNotNull(NewClassPage);

        NewClassPage.finish();
    }

    @After
    public void tearDown() throws Exception {

        testRule = null;
    }

}