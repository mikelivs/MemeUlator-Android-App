package edu.jermstadsbvcu.gradememeulator;

/*
WORKING ON GETTING THE GRADES TO SAVE TO THE SPECIFIC CLASS(MIGHT OR MIGHT NOT WORK CORRECTLY)

User Story 17: As a user I want to be able to navigate the grade input and final grade page fluently.

Scenario 1: At the final grade page I want to be able to click the help button to have a message appear on how to use the page

Scenario 2: Given the final grade page,I want my first calculated grade to be saved so that i can go back to the main menu to choose a new class to calculate the grade for.

Scenario 3: Given the grade input page, I want to be able to save my input when I return advance forward and backward a page so that it'll be there when i return.

*/
import android.support.test.espresso.ViewInteraction;
import android.support.test.rule.ActivityTestRule;
import android.support.test.runner.AndroidJUnit4;
import android.test.suitebuilder.annotation.LargeTest;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;

import org.hamcrest.Description;
import org.hamcrest.Matcher;
import org.hamcrest.TypeSafeMatcher;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

import static android.support.test.espresso.Espresso.onView;
import static android.support.test.espresso.Espresso.pressBack;
import static android.support.test.espresso.action.ViewActions.click;
import static android.support.test.espresso.action.ViewActions.closeSoftKeyboard;
import static android.support.test.espresso.action.ViewActions.replaceText;
import static android.support.test.espresso.action.ViewActions.scrollTo;
import static android.support.test.espresso.matcher.ViewMatchers.isDisplayed;
import static android.support.test.espresso.matcher.ViewMatchers.withId;
import static android.support.test.espresso.matcher.ViewMatchers.withParent;
import static android.support.test.espresso.matcher.ViewMatchers.withText;
import static org.hamcrest.Matchers.allOf;

@LargeTest
@RunWith(AndroidJUnit4.class)
public class UserStory17_test {

    @Rule
    public ActivityTestRule<NewMainActivity> mActivityTestRule = new ActivityTestRule<>(NewMainActivity.class);

    @Test
    public void userStory17_test() {
        ViewInteraction appCompatEditText = onView(
                allOf(withId(R.id.txtinput), isDisplayed()));
        appCompatEditText.perform(replaceText("test17"), closeSoftKeyboard());

        ViewInteraction appCompatButton = onView(
                allOf(withId(R.id.btAddClass), withText("Add"), isDisplayed()));
        appCompatButton.perform(click());

        ViewInteraction relativeLayout = onView(
                allOf(childAtPosition(
                        withId(R.id.list),
                        0),
                        isDisplayed()));
        relativeLayout.perform(click());

        ViewInteraction appCompatEditText2 = onView(
                withId(R.id.hwInputW));
        appCompatEditText2.perform(scrollTo(), replaceText("50"), closeSoftKeyboard());

        ViewInteraction appCompatEditText3 = onView(
                withId(R.id.hwInputG));
        appCompatEditText3.perform(scrollTo(), replaceText("50"), closeSoftKeyboard());

        ViewInteraction appCompatEditText4 = onView(
                withId(R.id.quizInputW));
        appCompatEditText4.perform(scrollTo(), replaceText("50"), closeSoftKeyboard());

        ViewInteraction appCompatEditText5 = onView(
                withId(R.id.quizInputG));
        appCompatEditText5.perform(scrollTo(), replaceText("50"), closeSoftKeyboard());

        ViewInteraction appCompatEditText6 = onView(
                withId(R.id.testInputW));
        appCompatEditText6.perform(scrollTo(), replaceText("50"), closeSoftKeyboard());

        ViewInteraction appCompatEditText7 = onView(
                withId(R.id.TestsInputG));
        appCompatEditText7.perform(scrollTo(), replaceText("50"), closeSoftKeyboard());

        ViewInteraction appCompatEditText8 = onView(
                withId(R.id.projectInputW));
        appCompatEditText8.perform(scrollTo(), replaceText("50"), closeSoftKeyboard());

        ViewInteraction appCompatEditText9 = onView(
                withId(R.id.projectInputG));
        appCompatEditText9.perform(scrollTo(), replaceText("50"), closeSoftKeyboard());

        ViewInteraction appCompatButton2 = onView(
                allOf(withId(R.id.subButton), withText("Submit"),
                        withParent(allOf(withId(R.id.activity_weitght),
                                withParent(withId(android.R.id.content)))),
                        isDisplayed()));
        appCompatButton2.perform(click());

        ViewInteraction appCompatButton3 = onView(
                allOf(withId(R.id.calcbutton), withText("Calculate"),
                        withParent(allOf(withId(R.id.activity_final_grade),
                                withParent(withId(android.R.id.content)))),
                        isDisplayed()));
        appCompatButton3.perform(click());

        ViewInteraction appCompatButton4 = onView(
                allOf(withId(R.id.fhelpButton), withText("Help"),
                        withParent(allOf(withId(R.id.activity_final_grade),
                                withParent(withId(android.R.id.content)))),
                        isDisplayed()));
        appCompatButton4.perform(click());

        ViewInteraction appCompatButton5 = onView(
                allOf(withId(R.id.menuButton), withText("Main Menu"),
                        withParent(allOf(withId(R.id.activity_final_grade),
                                withParent(withId(android.R.id.content)))),
                        isDisplayed()));
        appCompatButton5.perform(click());

        ViewInteraction relativeLayout2 = onView(
                allOf(childAtPosition(
                        withId(R.id.list),
                        0),
                        isDisplayed()));
        relativeLayout2.perform(click());

        ViewInteraction appCompatButton6 = onView(
                allOf(withId(R.id.subButton), withText("Submit"),
                        withParent(allOf(withId(R.id.activity_weitght),
                                withParent(withId(android.R.id.content)))),
                        isDisplayed()));
        appCompatButton6.perform(click());

        ViewInteraction appCompatButton7 = onView(
                allOf(withId(R.id.calcbutton), withText("Calculate"),
                        withParent(allOf(withId(R.id.activity_final_grade),
                                withParent(withId(android.R.id.content)))),
                        isDisplayed()));
        appCompatButton7.perform(click());

        ViewInteraction appCompatButton8 = onView(
                allOf(withId(R.id.backbutton), withText("Back"),
                        withParent(allOf(withId(R.id.activity_final_grade),
                                withParent(withId(android.R.id.content)))),
                        isDisplayed()));
        appCompatButton8.perform(click());

        pressBack();

        pressBack();

        pressBack();

        pressBack();

        ViewInteraction appCompatButton9 = onView(
                allOf(withId(R.id.list_item_dButton), withText("delete"),
                        withParent(childAtPosition(
                                withId(R.id.list),
                                5)),
                        isDisplayed()));
        appCompatButton9.perform(click());

        ViewInteraction appCompatButton10 = onView(
                allOf(withId(R.id.list_item_dButton), withText("delete"),
                        withParent(childAtPosition(
                                withId(R.id.list),
                                5)),
                        isDisplayed()));
        appCompatButton10.perform(click());

        ViewInteraction appCompatButton11 = onView(
                allOf(withId(R.id.list_item_dButton), withText("delete"),
                        withParent(childAtPosition(
                                withId(R.id.list),
                                0)),
                        isDisplayed()));
        appCompatButton11.perform(click());

    }

    private static Matcher<View> childAtPosition(
            final Matcher<View> parentMatcher, final int position) {

        return new TypeSafeMatcher<View>() {
            @Override
            public void describeTo(Description description) {
                description.appendText("Child at position " + position + " in parent ");
                parentMatcher.describeTo(description);
            }

            @Override
            public boolean matchesSafely(View view) {
                ViewParent parent = view.getParent();
                return parent instanceof ViewGroup && parentMatcher.matches(parent)
                        && view.equals(((ViewGroup) parent).getChildAt(position));
            }
        };
    }
}
