package edu.jermstadsbvcu.gradememeulator;

import android.app.Activity;
import android.app.Instrumentation;
import android.support.test.rule.ActivityTestRule;

import org.junit.After;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;

import static android.support.test.InstrumentationRegistry.getInstrumentation;
import static android.support.test.espresso.Espresso.onView;
import static android.support.test.espresso.action.ViewActions.click;
import static android.support.test.espresso.matcher.ViewMatchers.withId;
import static junit.framework.Assert.assertNotNull;
import static org.junit.Assert.*;

/**
 * Created by JeffNguyen on 3/25/17.
 */
public class userStory2_Scenario1 {
    @Rule
    public ActivityTestRule<MainActivity> userStory2TestRule = new ActivityTestRule<MainActivity>(MainActivity.class);

    private MainActivity userStory2 = null;

    Instrumentation.ActivityMonitor monitor = getInstrumentation().addMonitor(weitght.class.getName(), null, false);

    @Before
    public void setUp() throws Exception
    {
        userStory2 = userStory2TestRule.getActivity();
    }

    @Test
    public void testWeightsButtonClick()
    {
        assertNotNull(userStory2.findViewById(R.id.wButton));
        onView(withId(R.id.wButton)).perform(click());

        Activity weight = getInstrumentation().waitForMonitorWithTimeout(monitor, 5000);
        assertNotNull(weight);
        weight.finish();

    }


    @After
    public void tearDown() throws Exception
    {
        userStory2 = null;
    }

}