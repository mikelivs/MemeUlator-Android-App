package edu.jermstadsbvcu.gradememeulator;

import android.app.Activity;
import android.app.Instrumentation;
import android.support.test.rule.ActivityTestRule;

import org.junit.After;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;

import static android.support.test.InstrumentationRegistry.getInstrumentation;
import static android.support.test.espresso.Espresso.onView;
import static android.support.test.espresso.action.ViewActions.click;
import static android.support.test.espresso.matcher.ViewMatchers.withId;
import static junit.framework.Assert.assertNotNull;

/**
 * Created by JeffNguyen on 3/25/17.
 */

public class userStory2_Scenario3
{
    @Rule
    public ActivityTestRule<grades> userStory2TestRule = new ActivityTestRule<grades>(grades.class);

    private grades userStory2 = null;

    Instrumentation.ActivityMonitor monitor = getInstrumentation().addMonitor(weitght.class.getName(), null, false);

    @Before
    public void setUp() throws Exception
    {
        userStory2 = userStory2TestRule.getActivity();
    }

    @Test
    public void testBackButtonClick()
    {
        assertNotNull(userStory2.findViewById(R.id.backButton));
        onView(withId(R.id.backButton)).perform(click());

        Activity weight = getInstrumentation().waitForMonitorWithTimeout(monitor, 5000);
        assertNotNull(weight);
        weight.finish();

    }


    @After
    public void tearDown() throws Exception
    {
        userStory2 = null;
    }
}
