package edu.jermstadsbvcu.gradememeulator;

import android.app.Activity;
import android.app.Instrumentation;
import android.support.test.rule.ActivityTestRule;

import org.junit.After;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;

import static android.support.test.InstrumentationRegistry.getInstrumentation;
import static android.support.test.espresso.Espresso.onView;
import static android.support.test.espresso.action.ViewActions.click;
import static android.support.test.espresso.matcher.ViewMatchers.withId;
import static junit.framework.Assert.assertNotNull;

/**
 * Created by steve on 4/6/2017.
 */

public class weightPageTest {

    @Rule
    public ActivityTestRule<weitght> weitghtActivityTestRule = new ActivityTestRule<weitght>(weitght.class);

    private weitght testRule = null;

    Instrumentation.ActivityMonitor monitor = getInstrumentation().addMonitor(finalGrade.class.getName(),null,false);

    @Before
    public void setUp() throws Exception {

        testRule = weitghtActivityTestRule.getActivity();


    }

    @Test
    public void testLaunchOfSecondActivityOnButtonClick(){

        assertNotNull(testRule.findViewById(R.id.subButton));

        onView(withId(R.id.subButton)).perform(click());

        Activity submitTest = getInstrumentation().waitForMonitorWithTimeout(monitor,5000);

        assertNotNull(submitTest);

        submitTest.finish();
    }

    @After
    public void tearDown() throws Exception {

        testRule = null;
    }

}

