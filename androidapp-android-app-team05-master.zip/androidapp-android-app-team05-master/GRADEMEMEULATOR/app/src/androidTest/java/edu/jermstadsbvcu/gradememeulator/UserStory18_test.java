package edu.jermstadsbvcu.gradememeulator;

/*
 Still working on getting the app to save the class grades(might or might not work)

User Story 18: As a user I want a meme to correctly display the outcome of my grade, whether good, neutral or bad.

Scenario 1: On the final grade page, I want to be able to repeatedly click the calculate button to generate a meme based on the grade i got for the specific class I inputted data for.

Scenario 2: On the new class input page i want to be able to have multiple classes saved so that i can return back so view the grade calculated for that class.

Scenario 3: Given the calculate button, I want the memes to be different for each class i calculate my grades for.

*/

import android.support.test.espresso.ViewInteraction;
import android.support.test.rule.ActivityTestRule;
import android.support.test.runner.AndroidJUnit4;
import android.test.suitebuilder.annotation.LargeTest;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;

import org.hamcrest.Description;
import org.hamcrest.Matcher;
import org.hamcrest.TypeSafeMatcher;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

import static android.support.test.espresso.Espresso.onView;
import static android.support.test.espresso.action.ViewActions.click;
import static android.support.test.espresso.action.ViewActions.closeSoftKeyboard;
import static android.support.test.espresso.action.ViewActions.replaceText;
import static android.support.test.espresso.action.ViewActions.scrollTo;
import static android.support.test.espresso.matcher.ViewMatchers.isDisplayed;
import static android.support.test.espresso.matcher.ViewMatchers.withId;
import static android.support.test.espresso.matcher.ViewMatchers.withParent;
import static android.support.test.espresso.matcher.ViewMatchers.withText;
import static org.hamcrest.Matchers.allOf;

@LargeTest
@RunWith(AndroidJUnit4.class)
public class UserStory18_test {

    @Rule
    public ActivityTestRule<NewMainActivity> mActivityTestRule = new ActivityTestRule<>(NewMainActivity.class);

    @Test
    public void userStory18_test() {
        ViewInteraction appCompatEditText = onView(
                allOf(withId(R.id.txtinput), isDisplayed()));
        appCompatEditText.perform(replaceText("test18"), closeSoftKeyboard());

        ViewInteraction appCompatButton = onView(
                allOf(withId(R.id.btAddClass), withText("Add"), isDisplayed()));
        appCompatButton.perform(click());

        ViewInteraction relativeLayout = onView(
                allOf(childAtPosition(
                        withId(R.id.list),
                        0),
                        isDisplayed()));
        relativeLayout.perform(click());

        ViewInteraction appCompatEditText2 = onView(
                withId(R.id.hwInputW));
        appCompatEditText2.perform(scrollTo(), replaceText("70"), closeSoftKeyboard());

        ViewInteraction appCompatEditText3 = onView(
                withId(R.id.hwInputG));
        appCompatEditText3.perform(scrollTo(), replaceText("25"), closeSoftKeyboard());

        ViewInteraction appCompatEditText4 = onView(
                withId(R.id.quizInputW));
        appCompatEditText4.perform(scrollTo(), replaceText("60"), closeSoftKeyboard());

        ViewInteraction appCompatEditText5 = onView(
                withId(R.id.quizInputG));
        appCompatEditText5.perform(scrollTo(), replaceText("25"), closeSoftKeyboard());

        ViewInteraction appCompatEditText6 = onView(
                withId(R.id.testInputW));
        appCompatEditText6.perform(scrollTo(), replaceText("55"), closeSoftKeyboard());

        ViewInteraction appCompatEditText7 = onView(
                withId(R.id.TestsInputG));
        appCompatEditText7.perform(scrollTo(), replaceText("25"), closeSoftKeyboard());

        ViewInteraction appCompatEditText8 = onView(
                withId(R.id.projectInputW));
        appCompatEditText8.perform(scrollTo(), replaceText("65"), closeSoftKeyboard());

        ViewInteraction appCompatEditText9 = onView(
                withId(R.id.projectInputG));
        appCompatEditText9.perform(scrollTo(), replaceText("25"), closeSoftKeyboard());

        ViewInteraction appCompatButton2 = onView(
                allOf(withId(R.id.subButton), withText("Submit"),
                        withParent(allOf(withId(R.id.activity_weitght),
                                withParent(withId(android.R.id.content)))),
                        isDisplayed()));
        appCompatButton2.perform(click());

        ViewInteraction appCompatButton3 = onView(
                allOf(withId(R.id.calcbutton), withText("Calculate"),
                        withParent(allOf(withId(R.id.activity_final_grade),
                                withParent(withId(android.R.id.content)))),
                        isDisplayed()));
        appCompatButton3.perform(click());

        ViewInteraction appCompatButton4 = onView(
                allOf(withId(R.id.calcbutton), withText("Calculate"),
                        withParent(allOf(withId(R.id.activity_final_grade),
                                withParent(withId(android.R.id.content)))),
                        isDisplayed()));
        appCompatButton4.perform(click());

        ViewInteraction appCompatButton5 = onView(
                allOf(withId(R.id.calcbutton), withText("Calculate"),
                        withParent(allOf(withId(R.id.activity_final_grade),
                                withParent(withId(android.R.id.content)))),
                        isDisplayed()));
        appCompatButton5.perform(click());

        ViewInteraction appCompatButton6 = onView(
                allOf(withId(R.id.calcbutton), withText("Calculate"),
                        withParent(allOf(withId(R.id.activity_final_grade),
                                withParent(withId(android.R.id.content)))),
                        isDisplayed()));
        appCompatButton6.perform(click());

        ViewInteraction appCompatButton7 = onView(
                allOf(withId(R.id.calcbutton), withText("Calculate"),
                        withParent(allOf(withId(R.id.activity_final_grade),
                                withParent(withId(android.R.id.content)))),
                        isDisplayed()));
        appCompatButton7.perform(click());

        ViewInteraction appCompatButton8 = onView(
                allOf(withId(R.id.menuButton), withText("Main Menu"),
                        withParent(allOf(withId(R.id.activity_final_grade),
                                withParent(withId(android.R.id.content)))),
                        isDisplayed()));
        appCompatButton8.perform(click());

        ViewInteraction appCompatEditText10 = onView(
                allOf(withId(R.id.txtinput), isDisplayed()));
        appCompatEditText10.perform(replaceText("test19"), closeSoftKeyboard());

        ViewInteraction appCompatButton9 = onView(
                allOf(withId(R.id.btAddClass), withText("Add"), isDisplayed()));
        appCompatButton9.perform(click());

        ViewInteraction appCompatEditText11 = onView(
                allOf(withId(R.id.txtinput), isDisplayed()));
        appCompatEditText11.perform(replaceText("test19"), closeSoftKeyboard());

        ViewInteraction appCompatButton10 = onView(
                allOf(withId(R.id.btAddClass), withText("Add"), isDisplayed()));
        appCompatButton10.perform(click());

        ViewInteraction appCompatButton11 = onView(
                allOf(withId(R.id.list_item_dButton), withText("delete"),
                        withParent(childAtPosition(
                                withId(R.id.list),
                                0)),
                        isDisplayed()));
        appCompatButton11.perform(click());

        ViewInteraction appCompatButton12 = onView(
                allOf(withId(R.id.list_item_dButton), withText("delete"),
                        withParent(childAtPosition(
                                withId(R.id.list),
                                0)),
                        isDisplayed()));
        appCompatButton12.perform(click());

        ViewInteraction relativeLayout2 = onView(
                allOf(childAtPosition(
                        withId(R.id.list),
                        0),
                        isDisplayed()));
        relativeLayout2.perform(click());

        ViewInteraction appCompatEditText12 = onView(
                withId(R.id.hwInputW));
        appCompatEditText12.perform(scrollTo(), replaceText("100"), closeSoftKeyboard());

        ViewInteraction appCompatEditText13 = onView(
                withId(R.id.hwInputG));
        appCompatEditText13.perform(scrollTo(), replaceText("100"), closeSoftKeyboard());

        ViewInteraction appCompatEditText14 = onView(
                withId(R.id.quizInputW));
        appCompatEditText14.perform(scrollTo(), replaceText("100"), closeSoftKeyboard());

        ViewInteraction appCompatEditText15 = onView(
                withId(R.id.quizInputG));
        appCompatEditText15.perform(scrollTo(), replaceText("100"), closeSoftKeyboard());

        ViewInteraction appCompatEditText16 = onView(
                withId(R.id.testInputW));
        appCompatEditText16.perform(scrollTo(), replaceText("100"), closeSoftKeyboard());

        ViewInteraction appCompatEditText17 = onView(
                withId(R.id.TestsInputG));
        appCompatEditText17.perform(scrollTo(), replaceText("100"), closeSoftKeyboard());

        ViewInteraction appCompatEditText18 = onView(
                withId(R.id.projectInputW));
        appCompatEditText18.perform(scrollTo(), replaceText("100"), closeSoftKeyboard());

        ViewInteraction appCompatEditText19 = onView(
                withId(R.id.projectInputG));
        appCompatEditText19.perform(scrollTo(), replaceText("100"), closeSoftKeyboard());

        ViewInteraction appCompatButton13 = onView(
                allOf(withId(R.id.subButton), withText("Submit"),
                        withParent(allOf(withId(R.id.activity_weitght),
                                withParent(withId(android.R.id.content)))),
                        isDisplayed()));
        appCompatButton13.perform(click());

        ViewInteraction appCompatButton14 = onView(
                allOf(withId(R.id.calcbutton), withText("Calculate"),
                        withParent(allOf(withId(R.id.activity_final_grade),
                                withParent(withId(android.R.id.content)))),
                        isDisplayed()));
        appCompatButton14.perform(click());

        ViewInteraction appCompatButton15 = onView(
                allOf(withId(R.id.calcbutton), withText("Calculate"),
                        withParent(allOf(withId(R.id.activity_final_grade),
                                withParent(withId(android.R.id.content)))),
                        isDisplayed()));
        appCompatButton15.perform(click());

        ViewInteraction appCompatButton16 = onView(
                allOf(withId(R.id.calcbutton), withText("Calculate"),
                        withParent(allOf(withId(R.id.activity_final_grade),
                                withParent(withId(android.R.id.content)))),
                        isDisplayed()));
        appCompatButton16.perform(click());

        ViewInteraction appCompatButton17 = onView(
                allOf(withId(R.id.calcbutton), withText("Calculate"),
                        withParent(allOf(withId(R.id.activity_final_grade),
                                withParent(withId(android.R.id.content)))),
                        isDisplayed()));
        appCompatButton17.perform(click());

        ViewInteraction appCompatButton18 = onView(
                allOf(withId(R.id.calcbutton), withText("Calculate"),
                        withParent(allOf(withId(R.id.activity_final_grade),
                                withParent(withId(android.R.id.content)))),
                        isDisplayed()));
        appCompatButton18.perform(click());

        ViewInteraction appCompatButton19 = onView(
                allOf(withId(R.id.calcbutton), withText("Calculate"),
                        withParent(allOf(withId(R.id.activity_final_grade),
                                withParent(withId(android.R.id.content)))),
                        isDisplayed()));
        appCompatButton19.perform(click());

        ViewInteraction appCompatButton20 = onView(
                allOf(withId(R.id.menuButton), withText("Main Menu"),
                        withParent(allOf(withId(R.id.activity_final_grade),
                                withParent(withId(android.R.id.content)))),
                        isDisplayed()));
        appCompatButton20.perform(click());

    }

    private static Matcher<View> childAtPosition(
            final Matcher<View> parentMatcher, final int position) {

        return new TypeSafeMatcher<View>() {
            @Override
            public void describeTo(Description description) {
                description.appendText("Child at position " + position + " in parent ");
                parentMatcher.describeTo(description);
            }

            @Override
            public boolean matchesSafely(View view) {
                ViewParent parent = view.getParent();
                return parent instanceof ViewGroup && parentMatcher.matches(parent)
                        && view.equals(((ViewGroup) parent).getChildAt(position));
            }
        };
    }
}
