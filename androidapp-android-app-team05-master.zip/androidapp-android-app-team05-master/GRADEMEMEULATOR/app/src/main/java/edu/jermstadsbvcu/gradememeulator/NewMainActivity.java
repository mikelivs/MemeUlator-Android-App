package edu.jermstadsbvcu.gradememeulator;

import android.app.ListActivity;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.support.annotation.LayoutRes;
import android.support.annotation.NonNull;
import android.support.v7.app.ActionBarActivity;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.ThemedSpinnerAdapter;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CursorAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static java.security.AccessController.getContext;

public class NewMainActivity extends AppCompatActivity {
    private EditText txtInput;
    private DataBaseHelper myDb;
    private Button help;
    ListView listView;
    Context context = this;
    Cursor cursor1;
    MyAdapter adapter;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_main);

        listView = (ListView) findViewById(R.id.list);
        myDb = new DataBaseHelper(context);
        txtInput = (EditText) findViewById(R.id.txtinput);
        Button btAdd = (Button) findViewById(R.id.btAddClass);
        help = (Button) findViewById(R.id.helpButton);
        cursor1 = myDb.getInfo(myDb);
        adapter = new MyAdapter(context, cursor1);
        listView.setAdapter(adapter);

        btAdd.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                String newClass = txtInput.getText().toString().trim();
                if(newClass.length() == 0 || newClass.equals(null)) //look for null user inputs
                {
                    Toast toast = Toast.makeText(context, "Insert Class Name", Toast.LENGTH_SHORT ); //toast for user
                    toast.show();
                }
                else {
                    myDb.insertData(newClass);
                    cursor1 = myDb.getInfo(myDb);
                    adapter = new MyAdapter(context, cursor1);
                    listView.setAdapter(adapter);
                    adapter.notifyDataSetChanged();
                    txtInput.setText("");
                }
            }
        });
        remove();

        // Help button creates a "Toast" pop up menu with instructions
        help.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v) {
                // Actual message text
                CharSequence text = "Input a new class that you want to calculate your grade" +
                        "Once class has been typed in, click on the 'add' button " +
                        "After class been added, click on the class you want ";

                Context context = getApplicationContext();
                // Time for the message to last is set to long
                int duration = Toast.LENGTH_LONG;
                Toast toast = Toast.makeText(context, text, duration);
                toast.show();
            }
        });

    }

    public void remove()
    {
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener()
        {

            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                startActivity(new Intent(NewMainActivity.this, weitght.class)); // go to next activity if user clicks on class listview
            }
        });
    }



    public class MyAdapter extends CursorAdapter //custom adaptetr to populate multiple classes from SQLite Database in a dynamic listview
    {
        Cursor cursor;
        LayoutInflater inflater;
        Context context;

        MyAdapter(Context context, Cursor cursor)
        {
            super(context, cursor);
            this.cursor = cursor;
            this.context =context;
            inflater = LayoutInflater.from(context);
        }

        @Override
        public View newView(Context context, Cursor cursor, ViewGroup parent) {
            return LayoutInflater.from(context).inflate(R.layout.list_item,parent,false);

        }

        @Override
        public void bindView(View view, final Context context, final Cursor cursor)
        {
            TextView className = (TextView) view.findViewById(R.id.list_item_text);
            className.setText(cursor.getString(cursor.getColumnIndex(DataBaseHelper.col1_name)));

            final String nameClass = cursor.getString(cursor.getColumnIndex(DataBaseHelper.col1_name));

            Button deleteButton = (Button) view.findViewById(R.id.list_item_dButton);

            deleteButton.setOnClickListener(new View.OnClickListener()
            {
                @Override
                public void onClick(View v)
                { //delete method
                    myDb.deleteClass(nameClass); //use database helper method to delete class
                    cursor1 = myDb.getInfo(myDb); //get class info from database as a cursor object
                    MyAdapter adapter = new MyAdapter(context, cursor1); //call new adapter to update layout
                    listView.setAdapter(adapter); //set the list view with updated adapter

                }
            });
        }
    }
}


