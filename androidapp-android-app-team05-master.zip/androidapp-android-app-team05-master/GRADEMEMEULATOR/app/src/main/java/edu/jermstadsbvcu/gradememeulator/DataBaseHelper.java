    package edu.jermstadsbvcu.gradememeulator;
    import android.content.ContentValues;
    import android.content.Context;
    import android.database.Cursor;
    import android.database.SQLException;
    import android.database.sqlite.SQLiteDatabase;
    import android.database.sqlite.SQLiteOpenHelper;
    import android.util.Log;
    import android.widget.CursorAdapter;
    import android.widget.SimpleCursorAdapter;


    /**
     * Created by Mike on 3/30/2017.
     */

    public class DataBaseHelper extends SQLiteOpenHelper {

        //intialize columns in datbase
        public static final String DATABASE_NAME = "Grades.db";
        public static final String table_NAME = "grades_Table";
        public static final String hw = "hw";
        public static final String quiz = "quiz";
        public static final String test = "test";
        public static final String projects = "projects";
        public static final String other = "other";
        public static final String col1_name = "className";
        public static final String KEY_ID = "_id";

        public static final String hwWeight = "hwWeight";
        public static final String quizWeight = "quizWeight";
        public static final String testWeight = "testWeight";
        public static final String projectsWeight = "projectsWeight";
        public static final String otherWeight = "otherWeight";


        SQLiteDatabase db;
        public Context context;


        public DataBaseHelper(Context context) //constructor to make database and table
        {

            super(context, DATABASE_NAME, null, 1); //creates databse when called
            //SQLiteDatabase db = this.getWritableDatabase();
            Log.e("DATABASE OPERATIONS", "DATABASE CREATED/OPENED");
        }

        @Override
        public void onCreate(SQLiteDatabase db) { //creates databse with given columns
            db.execSQL("CREATE TABLE " + table_NAME + " ("
                    + KEY_ID+ " integer primary key autoincrement, "//specific sql syntax!!
                    + col1_name + " TEXT, "
                    + hw + " TEXT," +
                    quiz+" TEXT," +
                    projects+" TEXT," +
                    other+" TEXT," +
                    test+" TEXT);");
            Log.e("DATABASE OPERATIONS", "TABLE CREATED/OPENED");
        }

        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            db.execSQL("DROP TABLE IF EXISTS " + table_NAME);
            onCreate(db);
        }

        public void insertData(String name) { //inserts classes into database
            db = this.getWritableDatabase();
            ContentValues contentValues = new ContentValues();
            contentValues.put(col1_name, name); //add data for other columns
            db.insert(table_NAME, null, contentValues); //insert if error returns -1
            db.close();
            Log.e("DATABASE OPERATIONS", "Data inserted");


        }

        public void insertHW(String grade) {
            db = this.getWritableDatabase();
            ContentValues contentValues = new ContentValues();
            contentValues.put(hw, grade); //add data for other columns
            db.insert(table_NAME, null, contentValues); //insert if error returns -1
            db.close();
            Log.e("DATABASE OPERATIONS", "Data inserted hw");


        }
        public void insertQuiz(String grade) {
            db = this.getWritableDatabase();
            ContentValues contentValues = new ContentValues();
            contentValues.put(quiz, grade); //add data for other columns
            db.insert(table_NAME, null, contentValues); //insert if error returns -1
            db.close();
            Log.e("DATABASE OPERATIONS", "Data inserted hw");


        }
        public void insertTest(String grade) {
            db = this.getWritableDatabase();
            ContentValues contentValues = new ContentValues();
            contentValues.put(test, grade); //add data for other columns
            db.insert(table_NAME, null, contentValues); //insert if error returns -1
            db.close();
            Log.e("DATABASE OPERATIONS", "Data inserted tests");


        }
        public void insertProject(String grade) {
            db = this.getWritableDatabase();
            ContentValues contentValues = new ContentValues();
            contentValues.put(projects, grade); //add data for other columns
            db.insert(table_NAME, null, contentValues); //insert if error returns -1
            db.close();
            Log.e("DATABASE OPERATIONS", "Data inserted projects");


        }
        public void insertOther(String grade) {
            db = this.getWritableDatabase();
            ContentValues contentValues = new ContentValues();
            contentValues.put(other, grade); //add data for other columns
            db.insert(table_NAME, null, contentValues); //insert if error returns -1
            db.close();
            Log.e("DATABASE OPERATIONS", "Data inserted other");


        }

        public void deleteClass(String cl) { //deletes class data for a specific class passed in
            SQLiteDatabase db = getWritableDatabase();
            db.execSQL("DELETE FROM " + table_NAME + " WHERE " + col1_name + "= '" + cl + "';");
            db.close();
            Log.e("DATABASE OPERATIONS", "deleted class");
        }

        public Cursor getInfo(DataBaseHelper db) //returns cursor object for viewing data in database
        {
            SQLiteDatabase sq = db.getReadableDatabase();
            Cursor cursor;
            String[] projections = {KEY_ID,col1_name}; //column names
            cursor = sq.query(table_NAME, projections, null, null, null, null, null);
            return cursor;
        }

        public Cursor getHW(DataBaseHelper db)  //not used, but return all the HWs in database
        {
            SQLiteDatabase sq = db.getReadableDatabase();
            Cursor cursor;
            String[] projections = {KEY_ID,hw}; //column names
            cursor = sq.query(table_NAME, projections, null, null, null, null, null);
            return cursor;
        }

        public DataBaseHelper open() throws SQLException {
            db = this.getWritableDatabase();
            return this;
        }
        public void close()
        {
            db.close();
        }

    }
