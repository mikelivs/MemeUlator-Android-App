package edu.jermstadsbvcu.gradememeulator;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import static android.R.attr.button;

public class MainActivity extends AppCompatActivity {

    private Button help;
    private Button NewClassPage;
    private Button weightPage;
    //private Button gradesPage;
    private Button finalGradePage;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        help = (Button) findViewById(R.id.mmhelpButton);
        NewClassPage = (Button) findViewById(R.id.ncButton);
        weightPage = (Button) findViewById(R.id.wButton);
        //gradesPage = (Button) findViewById(R.id.gButton);
        finalGradePage = (Button) findViewById(R.id.fgButton);



        NewClassPage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, NewClassPage.class));

            }


        });

        weightPage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, weitght.class));

            }


        });

//        gradesPage.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                startActivity(new Intent(MainActivity.this, grades.class));
//
//            }
//
//
//        });

        finalGradePage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, finalGrade.class));

            }


        });


        help.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v) {
                //startActivity(new Intent(grades.this, finalGrade.class));
                CharSequence text = "Click the NEW CLASS button to begin if its your first time" +
                        " using the app for the current class. If you already have the current class" +
                        " entered in the app go to the weight or grades page to update new grades" +
                        " since last use. If you finished press the Final Grade button to see your" +
                        " Grade and meme! ";

                Context context = getApplicationContext();
                int duration = Toast.LENGTH_LONG;

                Toast toast = Toast.makeText(context,text,duration);
                toast.show();
            }
        });


    }
}
