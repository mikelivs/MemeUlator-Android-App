package edu.jermstadsbvcu.gradememeulator;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class grades extends AppCompatActivity {

    // Initialize the variables
    private Button backButton;
    private Button continueButton;
    private Button help;
    private Button submit;
    private EditText hw;
    private EditText quizzes;
    private EditText tests;
    private EditText projects;
    private String hw1;
    private String quizzes1;
    private String tests1;
    private String projects1;


    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_grades);

        // Setting each button to a variable
        hw = (EditText) findViewById(R.id.HwInput);
        quizzes = (EditText) findViewById(R.id.QuizInput);
        tests = (EditText) findViewById(R.id.TestsInput);
        projects = (EditText) findViewById(R.id.projectInput);
        continueButton = (Button) findViewById(R.id.continueButtonG);
        backButton = (Button) findViewById(R.id.backButton);
        help = (Button) findViewById(R.id.ghelpButton);
        submit = (Button) findViewById(R.id.SubmitButton);

        // Getting weights sent form the weights class
        Intent intent = getIntent();
        final String hwWeight = intent.getStringExtra("hwWeight");
        final String quizWeight = intent.getStringExtra("quizzesW");
        final String testsWeight = intent.getStringExtra("testW");
        final String projectWeight = intent.getStringExtra("projectsW");

        // the submit button takes all of the user inputs and calculates the final grade using these
        // values along with the weights and sends them to the final grade page
        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Get the editText inputs from user on this page
                hw1 = hw.getText().toString();
                quizzes1 = quizzes.getText().toString();
                tests1 = tests.getText().toString();
                projects1 = projects.getText().toString();
                // Multiply the weight by grades value to get totals
                double hwTotal = Double.parseDouble(hwWeight) * Double.parseDouble(hw1);
                double quizTotal = Double.parseDouble(quizWeight) * Double.parseDouble(quizzes1);
                double testTotal = Double.parseDouble(testsWeight) * Double.parseDouble(tests1);
                double projectsTotal = Double.parseDouble(projectWeight) * Double.parseDouble(projects1);
                // Add all of the totals together and divide by 100 to get final grade
                double grade = (hwTotal + quizTotal + testTotal + projectsTotal) / 100;
                // Must be converted to String to use putExtra method
                String finalGrade = String.valueOf(grade);
                // Send finalGrade variable to FinalGrade class
                Intent myIntent = new Intent(v.getContext(), finalGrade.class);
                myIntent.putExtra("finalGrade", finalGrade);
                startActivityForResult(myIntent, 0);
            }

        });
        // back button takes you back to the new class page
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(grades.this, weitght.class));
            }
        });

        // The continue button sends you to the finalGrades class
        continueButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(grades.this, finalGrade.class));
            }
        });
        // Help button creates a "Toast" pop up menu with instructions
        help.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                CharSequence text = "Click on the input lines next to each header to enter the" +
                        "what the weight for each category. If your class does not have a given " +
                        "category (i.e. no projects) just leave that input blank.";

                Context context = getApplicationContext();
                int duration = Toast.LENGTH_LONG;

                Toast toast = Toast.makeText(context, text, duration);
                toast.show();
            }
        });
    }


}

