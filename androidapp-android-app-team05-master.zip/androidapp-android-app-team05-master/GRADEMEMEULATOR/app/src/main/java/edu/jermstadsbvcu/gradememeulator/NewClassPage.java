    package edu.jermstadsbvcu.gradememeulator;

    import android.content.Context;
    import android.content.Intent;
    import android.database.Cursor;
    import android.database.sqlite.SQLiteDatabase;
    import android.support.v7.app.AlertDialog;
    import android.support.v7.app.AppCompatActivity;
    import android.os.Bundle;
    import android.view.View;
    import android.widget.Button;
    import android.widget.EditText;
    import android.widget.TextView;
    import android.widget.Toast;

    public class NewClassPage extends AppCompatActivity {

        private Button continueButton;
        private Button backButton;
        private Button addButtton;
        private TextView classDisplay;
        private EditText className;
        private Button helpButton;
        private DataBaseHelper myDb;
        Context context =this;
        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_new_class_page);


            continueButton = (Button) findViewById(R.id.continueButton);
            backButton = (Button) findViewById(R.id.backButton);
            addButtton = (Button) findViewById(R.id.addButton);
            classDisplay = (TextView) findViewById(R.id.classDisplay);
            className = (EditText) findViewById(R.id.userInput);
            helpButton = (Button) findViewById(R.id.helpButton);
            //creates database call
            myDb = new DataBaseHelper(context);
            addData();

            continueButton.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick (View v){
            startActivity(new Intent(NewClassPage.this, weitght.class));
        }
        });

             backButton.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick (View v){
            startActivity(new Intent(NewClassPage.this, MainActivity.class));
        }
        });


            helpButton.setOnClickListener(new View.OnClickListener()

        {
            @Override
            public void onClick (View v){
            Toast.makeText(getBaseContext(), "Input your class name", Toast.LENGTH_SHORT).show();
        }
        });

    }

    public void addData()
    {
        addButtton.setOnClickListener(new View.OnClickListener()

        {
            public void onClick (View v){

                String ed_text = className.getText().toString().trim();
                //myDb = new DataBaseHelper(context);
                //have to confirm that actually adding it may not be
                if (ed_text.isEmpty() || ed_text.length() == 0 || ed_text.equals("") || ed_text == null)
                {
                    Toast.makeText(getBaseContext(), "Please input your class name", Toast.LENGTH_SHORT).show();
                }
                else {
                    myDb.insertData(ed_text);
                    classDisplay.setText("Class added: " + className.getText());
                    className.setText("");

                    //   Toast.makeText(getBaseContext(), "Class added", Toast.LENGTH_SHORT).show();
                    Cursor res = myDb.getInfo(myDb);
                    res.moveToFirst();
                    //can put error handling look for nothing/0
                    StringBuffer buffer = new StringBuffer();
                    while(res.moveToNext())
                    {
                        buffer.append("Class added: "+ res.getString(0)+"\n");
                    }
                    myDb.close();
                    showMessage("Your Classes",buffer.toString());

                }
            }
        });
    }

    public void showMessage(String title, String message){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.show();
    }

    }
