package edu.jermstadsbvcu.gradememeulator;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class weitght extends AppCompatActivity
{

    // Initialize the variables
    private Button help;
    private Button submit;
    private EditText hwG;
    private EditText hwW;
    private EditText quizzesG;
    private EditText quizW;
    private EditText tests;
    private EditText testsW1;
    private EditText projects;
    private EditText projectsW1;
    private EditText otherInputW;
    private EditText otherInputG;
    private String hwWeight;
    private String quizzesW;
    private String testsW;
    private String projectsW;
    private String otherWeight;



    private DataBaseHelper myDb;
    private Context context=this;



    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_weitght);
        myDb = new DataBaseHelper(context);


        // Setting each button to a variable
        help = (Button) findViewById(R.id.helpButton);
        submit = (Button) findViewById(R.id.subButton);
        hwG = (EditText) findViewById(R.id.hwInputG);
        hwW = (EditText) findViewById(R.id.hwInputW);
        quizzesG = (EditText) findViewById(R.id.quizInputG);
        quizW = (EditText) findViewById(R.id.quizInputW);
        tests = (EditText) findViewById(R.id.TestsInputG);
        testsW1 = (EditText) findViewById(R.id.testInputW);
        projects = (EditText) findViewById(R.id.projectInputG);
        projectsW1 = (EditText) findViewById(R.id.projectInputW);
        otherInputG = (EditText) findViewById(R.id.otherInputG);
        otherInputW = (EditText) findViewById(R.id.otherInputW);

        // the submit button takes all of the user inputs and sends them to the grades class
        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // set EditText values


                hwWeight = hwW.getText().toString();
                String hwGrade = hwG.getText().toString();
                if (hwWeight.length() == 0)
                {
                    hwWeight = "0";
                }

                if(hwGrade.length() == 0) {
                    hwGrade = "0";
                }

                else if(hwGrade.contains(","))
                {
                    String[] commaSplit = hwGrade.split(",");
                    double sum = 0;

                    for (String i : commaSplit) {
                        if (i.contains("/")) {
                            String[] gradesSplit = i.split("/");
                            double gradesDivide = (Double.parseDouble(gradesSplit[0]) /
                                    Double.parseDouble(gradesSplit[1])) * 100;
                            i = Double.toString(gradesDivide);

                        }
                        sum += Double.parseDouble(i.trim());
                        sum = sum / commaSplit.length;
                        hwGrade = Double.toString(sum);
                        hwGrade = hwGrade.substring(0, 4);
                    }
                }
                else if(hwGrade.contains("/"))
                {
                    String[] gradesSplit = hwGrade.split("/");
                    double gradesDivide = (Double.parseDouble(gradesSplit[0]) /
                            Double.parseDouble(gradesSplit[1])) * 100;
                    hwGrade = Double.toString(gradesDivide);

                }

////////////////////////////////////////////////////////////////////////////////////////////
                quizzesW = quizW.getText().toString();
                String quizzesGrade = quizzesG.getText().toString();
                if (quizzesW.length() == 0)
                {
                    quizzesW = "0";
                }

                if(quizzesGrade.length() == 0) {
                    quizzesGrade = "0";
                }

                else if(quizzesGrade.contains(","))
                {
                    String[] commaSplit = quizzesGrade.split(",");
                    double sum = 0;
                    for (String i : commaSplit) {
                        if (i.contains("/")) {
                            String[] gradesSplit = i.split("/");
                            double gradesDivide = (Double.parseDouble(gradesSplit[0]) /
                                    Double.parseDouble(gradesSplit[1])) * 100;
                            i = Double.toString(gradesDivide);

                        }
                        sum += Double.parseDouble(i.trim());
                        sum = sum / commaSplit.length;
                        quizzesGrade = Double.toString(sum);
                        quizzesGrade = quizzesGrade.substring(0, 4);
                    }
                }
                else if(quizzesGrade.contains("/"))
                {
                    String[] gradesSplit1 = quizzesGrade.split("/");
                    double gradesDivide1 = (Double.parseDouble(gradesSplit1[0])
                            / Double.parseDouble(gradesSplit1[1])) * 100;
                    quizzesGrade = Double.toString(gradesDivide1);

                }

                ///////////////////////////////////////////////////////////////////////
                testsW = testsW1.getText().toString();
                String testsGrade = tests.getText().toString();
                if (testsW.length() == 0)
                {
                    testsW = "0";
                }

                if(testsGrade.length() == 0) {
                    testsGrade = "0";
                }
                else if(testsGrade.contains(","))
                {
                    String[] commaSplit = hwGrade.split(",");
                    double sum = 0;

                    for (String i : commaSplit) {
                        if (i.contains("/")) {
                            String[] gradesSplit = i.split("/");
                            double gradesDivide = (Double.parseDouble(gradesSplit[0]) /
                                    Double.parseDouble(gradesSplit[1])) * 100;
                            i = Double.toString(gradesDivide);
                        }
                        sum += Double.parseDouble(i);
                        sum = sum / commaSplit.length;
                        testsGrade = Double.toString(sum);
                        testsGrade = hwGrade.substring(0, 4);
                    }
                }
                else if(testsGrade.contains("/"))
                {
                    String[] gradesSplit2 = testsGrade.split("/");
                    double gradesDivide2 = (Double.parseDouble(gradesSplit2[0])
                            / Double.parseDouble(gradesSplit2[1])) * 100;
                    testsGrade = Double.toString(gradesDivide2);

                }
                ///////////////////////////////////////////////////////////////////////////////
                projectsW = projectsW1.getText().toString();
                String projectGrade = projects.getText().toString();
                if (projectsW.length() == 0)
                {
                    projectsW = "0";
                }

                if(projectGrade.length() == 0) {
                    projectGrade = "0";
                }
                else if(projectGrade.contains(","))
                {
                    String[] commaSplit = projectGrade.split(",");
                    double sum = 0;

                    for (String i : commaSplit) {
                        if (i.contains("/")) {
                            String[] gradesSplit = i.split("/");
                            double gradesDivide = (Double.parseDouble(gradesSplit[0]) /
                                    Double.parseDouble(gradesSplit[1])) * 100;
                            i = Double.toString(gradesDivide);
                        }
                        sum += Double.parseDouble(i.trim());
                        sum = sum / commaSplit.length;
                        projectGrade = Double.toString(sum);
                        projectGrade = projectGrade.substring(0, 4);
                    }
                }
                else if(projectGrade.contains("/"))
                {
                    String[] gradesSplit3 = projectGrade.split("/");
                    double gradesDivide3 = (Double.parseDouble(gradesSplit3[0])
                            / Double.parseDouble(gradesSplit3[1])) * 100;
                    projectGrade = Double.toString(gradesDivide3);
                }
                /////////////////////////////////////////////////////////////////////////////
                otherWeight = otherInputW.getText().toString();
                String otherGrade = otherInputG.getText().toString();
                if (otherWeight.length() == 0)
                {
                    otherWeight = "0";
                }

                if(otherGrade.length() == 0) {
                    otherGrade = "0";
                }
                else if(otherGrade.contains(","))
                {
                    String[] commaSplit = otherGrade.split(",");
                    double sum = 0;

                    for (String i : commaSplit) {
                        if (i.contains("/")) {
                            String[] gradesSplit = i.split("/");
                            double gradesDivide = (Double.parseDouble(gradesSplit[0]) /
                                    Double.parseDouble(gradesSplit[1])) * 100;
                            i = Double.toString(gradesDivide);
                        }
                        sum += Double.parseDouble(i);
                        sum = sum / commaSplit.length;
                        otherGrade = Double.toString(sum);
                        otherGrade = otherGrade.substring(0, 4);
                    }
                }
                else if(otherGrade.contains("/"))
                {
                    String[] gradesSplit = otherGrade.split("/");
                    double gradesDivide = (Double.parseDouble(gradesSplit[0]) /
                            Double.parseDouble(gradesSplit[1])) * 100;
                    otherGrade = Double.toString(gradesDivide);

                }

////////////////////////////////////////////////////////////////////////////////////////////



                //insert data into SQLite database1
                myDb.insertHW(hwGrade);
                myDb.insertProject(projectGrade);
                myDb.insertQuiz(quizzesGrade);
                myDb.insertTest(testsGrade);
                myDb.insertOther(otherGrade);



                // Intent using "putExtra" sends the data to grades
                double hwTotal = Double.parseDouble(hwWeight.trim()) * Double.parseDouble(hwGrade.trim());
                double quizTotal = Double.parseDouble(quizzesW.trim()) * Double.parseDouble(quizzesGrade.trim());
                double testTotal = Double.parseDouble(testsW.trim()) * Double.parseDouble(testsGrade.trim());
                double projectsTotal = Double.parseDouble(projectsW.trim()) * Double.parseDouble(projectGrade.trim());
                double otherTotal = Double.parseDouble(otherWeight.trim()) * Double.parseDouble(otherGrade.trim());

                // Add all of the totals together and divide by 100 to get final grade
                double grade = (hwTotal + quizTotal + testTotal + projectsTotal + otherTotal) / 100;
                // Must be converted to String to use putExtra method
                String finalGrade = String.valueOf(grade);
                // Send finalGrade variable to FinalGrade class
                Intent myIntent = new Intent(v.getContext(), finalGrade.class);
                myIntent.putExtra("finalGrade", finalGrade);
                startActivityForResult(myIntent, 0);
            }

        });

        // Help button creates a "Toast" pop up menu with instructions
        help.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v) {
                // Actual message text
                CharSequence text = "Click on the input lines next to each header to enter the " +
                        "current grade for that category (if homework is 20% of grade, enter 20 in " +
                        "HW input. If your class does not have a given " +
                        "category (i.e. no projects) just leave that input blank.";

                Context context = getApplicationContext();
                // Time for the message to last is set to long
                int duration = Toast.LENGTH_LONG;
                Toast toast = Toast.makeText(context,text,duration);
                toast.show();
            }
        });

    }

}
