package edu.jermstadsbvcu.gradememeulator;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import static java.lang.Math.random;


public class finalGrade extends AppCompatActivity {

    // Initialize the variables
    private ImageView memeView1;
    private Button help;
    private Button menuButton;
    private Button backButton;
    private double tests;
    private TextView gradeWindow;
    private Button calculate;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_final_grade);

        // Setting each button to a variable
        calculate = (Button) findViewById(R.id.calcbutton);
        gradeWindow = (TextView) findViewById(R.id.gradeWindow);
        help = (Button) findViewById(R.id.fhelpButton);
        menuButton = (Button) findViewById(R.id.menuButton);
        backButton = (Button) findViewById(R.id.backbutton);

        // Meme generator


        // The calculate button shows the user his final grade along with a meme
        calculate.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v) {
                Intent intent = getIntent();
                // Accepts final grade value calculated in the grades class
                String finalGrade = intent.getStringExtra("finalGrade");
                double finalGradeNum = Double.parseDouble(finalGrade.trim());
                // Shows the user his grade
                gradeWindow.setText("Final Grade: " + finalGradeNum + "%");

                memeView1 = (ImageView) findViewById(R.id.imageView);
                if(finalGradeNum < 69.5) {
                    int[] badMemes = {R.drawable.b1, R.drawable.b2, R.drawable.b3, R.drawable.b4, R.drawable.b5,
                            R.drawable.b6, R.drawable.b7, R.drawable.b8, R.drawable.b9}; //intialize meme array
                    int random = (int) (random() * badMemes.length + 0); //random number for index of meme [] , 0 to length of memes int array
                    memeView1.setBackgroundResource(badMemes[random]);
                }

                if(finalGradeNum > 79.5) {
                    int[] goodMemes = {R.drawable.g1, R.drawable.g2, R.drawable.g3, R.drawable.g4, R.drawable.g5,
                            R.drawable.g6, R.drawable.g7, R.drawable.g8, R.drawable.g9}; //intialize meme array
                    int random = (int) (random() * goodMemes.length + 0); //random number for index of meme [] , 0 to length of memes int array
                    memeView1.setBackgroundResource(goodMemes[random]);
                }

                if(finalGradeNum > 69.5 && finalGradeNum < 79.5) {
                    int[] neutralMemes = {R.drawable.n1, R.drawable.n2, R.drawable.n3, R.drawable.n4}; //intialize meme array
                    int random = (int) (random() * neutralMemes.length + 0); //random number for index of meme [] , 0 to length of memes int array
                    memeView1.setBackgroundResource(neutralMemes[random]);
                }
            }
        });

        // Help button creates a "Toast" pop up menu with instructions
        help.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v) {
                CharSequence text = "If the grade does not appear accurate, go back to the weight" +
                        "and grades page to double check your input. Thank you for using " +
                        "GRADE MEMEULATOR!!";

                Context context = getApplicationContext();
                int duration = Toast.LENGTH_LONG;

                Toast toast = Toast.makeText(context,text,duration);
                toast.show();
            }
        });
        // Sends user back to main menu page
        menuButton.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(finalGrade.this, NewMainActivity.class));
            }
        });
        // takes user back to the grades page
        backButton.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(finalGrade.this, weitght.class));
            }
        });



    }
}
